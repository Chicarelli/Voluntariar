Voluntariar

O "Voluntariar" é um projeto desenvolvido com propósitos acadêmicos, proporcionando não só o aprendizado sobre o ambiente de desenvolvimento Android por meio da linguagem Java como também a conclusão do Trabalho de Conclusão de Curso.
